let tentativesRestantes = 3; 
let scoreActuel = 0;
let totalScore = []; 
let desLances = 0;
const desParTentative = 8; 



const joueurs = JSON.parse(localStorage.getItem('playerNames'));// Récupération des noms 
let joueurActuel = 0;// initialiser l'indice


const lancerDeBtn = document.getElementById('lancerDe');
const arreterBtn = document.getElementById('arreter');
const tentativesRestantesEl = document.getElementById('tentativesRestantes');
const desRestantsEl = document.getElementById('desRestants');
const scoreActuelEl = document.getElementById('scoreActuel');
const totalScoreEl = document.getElementById('totalScore'); 
const messageEl = document.getElementById('message');
const resultatsDesEl = document.getElementById('resultatsDes');
const playerNameEl = document.querySelector('.player-name'); 
const voirClassementBtn = document.getElementById('voirClassement');


totalScore = Array(joueurs.length).fill(0); // tableau avec des scores totaux initialisés à 0

playerNameEl.textContent = joueurs[joueurActuel]; // Affichage



// Fonction pour lancer un dé
function lancerUnDe() {
    if (desLances < desParTentative) {
        let resultat = Math.floor(Math.random() * 6) + 1; 
        desLances++;

        // Crée un élément pour rep le dé lancé
        const deEl = document.createElement('div');
        deEl.className = 'de'; // Attribue une classe CSS 'de' 
        deEl.textContent = resultat; // Affiche le résultat sur l'élément du dé
        resultatsDesEl.appendChild(deEl); // Ajoute cet élmt à un conteneur sur la page enf p

        
        if (resultat === 1) {
            messageEl.textContent = "Vous avez obtenu un as ! Vous perdez cette tentative.";
            scoreActuel = 0; 
            terminerTentative(); // Terminer la tentative immédiatement
        } else {
            scoreActuel += resultat; 
            scoreActuelEl.textContent = scoreActuel; // Mettre à jour l'affichage 
            messageEl.textContent = `Vous avez obtenu un ${resultat}. Continuez ou arrêtez-vous.`;
            arreterBtn.disabled = false; // Activer le bouton d'arrêt
        }

        // Mettre à jour le nombre de dés restants
        const desRestants = desParTentative - desLances;
        desRestantsEl.textContent = desRestants; // Afficher les dés restants
    }

    
    if (desLances === desParTentative) {
        messageEl.textContent = "Vous avez lancé tous les dés.";
        terminerTentative();
    }
}


// Fonction pour lancer les dés
function lancerDes() {
    lancerUnDe(); 
}

// Fonction pour arrêter la tentative en cours
function arreterTentative() {
    totalScore[joueurActuel] += scoreActuel; 
    totalScoreEl.textContent = totalScore[joueurActuel]; 
    terminerTentative();
}



// Fonction pour gérer la fin d'une tentative
function terminerTentative() {
    tentativesRestantes--; // Réduire le nombre de tentatives restantes


    // Vérifier si des tentatives restent pour le joueur actuel
    if (tentativesRestantes > 0) {
        tentativesRestantesEl.textContent = tentativesRestantes; // affichage 
        setTimeout(nouvelleTentative, 2000); // Attente

    } else {
        // Passer au joueur suivant
        joueurActuel = (joueurActuel + 1) % joueurs.length; 
        tentativesRestantes = 3; 
        scoreActuel = 0; 
        playerNameEl.textContent = joueurs[joueurActuel]; // Mis à jour du nom du jactuel
        tentativesRestantesEl.textContent = tentativesRestantes; // Réinitialiser les tentatives restantes
        totalScoreEl.textContent = totalScore[joueurActuel]; // Afficher le score total du nouveau joueur

        // Vérifier si tous les joueurs ont joué
        if (joueurActuel === 0) {
            messageEl.textContent = "Partie terminée !"; 
            localStorage.setItem('totalScore', JSON.stringify(totalScore)); // Enregistrer les scores dans le stockage local
            arreterBtn.disabled = true; // Désactiver le bouton d'arrêt à la fin de la partie
            afficherBoutonClassement(); // Afficher le bouton classement
        } else {
            setTimeout(nouvelleTentative, 2000); // Attendre avant de passer au joueur suivant
        }
    }

    lancerDeBtn.disabled = true; // Désactiver le bouton de lancer
}



// Fonction nouvelle tentative
function nouvelleTentative() {
    desLances = 0; 
    scoreActuel = 0; 
    scoreActuelEl.textContent = scoreActuel; //affichage 
    lancerDeBtn.disabled = false; 
    arreterBtn.disabled = true; 
    resultatsDesEl.innerHTML = ''; // Effacer les résultats de la tentative précédente
    messageEl.textContent = "Nouvelle tentative pour " + joueurs[joueurActuel];

    // Réinitialiser le compteur de dés restants
    const desRestants = desParTentative;
    desRestantsEl.textContent = desRestants; 
}


// Fonction pour afficher le bouton vers la page de classement
function afficherBoutonClassement() {
    voirClassementBtn.style.display = 'block'; 
}

// Ajouter les écouteurs d'événements
lancerDeBtn.addEventListener('click', lancerDes);
arreterBtn.addEventListener('click', arreterTentative);
voirClassementBtn.addEventListener('click', function() {
    window.location.href = 'rslt.html'; 
});
