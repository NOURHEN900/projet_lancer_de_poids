// selection de tous les élmts playername
document.querySelectorAll('.player-name').forEach(input => {

    // Efface le placeholder lorsque le champ est sélectionné
    input.addEventListener('focus', function () { 
        this.placeholder = '';
    });



    // Restaure le placeholder si le champ est vide
    input.addEventListener('blur', function () {
        if (this.value === '') {  // vérif si le champ vide
            this.placeholder = `Entrer le nom du joueur ${Array.from(document.querySelectorAll('.player-name')).indexOf(this) + 1}`; // texte dynamique (num du j)
        }
    });
});



const playButton = document.getElementById('playButton');
playButton.addEventListener('click', function() {
    const playerNames = Array.from(document.querySelectorAll('.player-name')).map(input => input.value.trim()); // Récupère les noms map tab trim cc
    localStorage.setItem('playerNames', JSON.stringify(playerNames)); // Enreg; transforme ce tableau en une chaîne de texte JSON,
    window.location.href = 'lancer.html'; 
});
