// Récupérer les scores et les noms des joueurs du localStorage
const scores = JSON.parse(localStorage.getItem('totalScore')) || [];
const joueurs = JSON.parse(localStorage.getItem('playerNames')) || ["Joueur 1", "Joueur 2", "Joueur 3", "Joueur 4"];

//tableau de joueurs + score
const classement = joueurs.map((joueur, index) => {
    return { nom: joueur, score: scores[index] };
});

// Tri décroissant
classement.sort((a, b) => b.score - a.score);

// Affichage classement 
const classementEl = document.getElementById('classement');
classement.forEach(joueur => {
    const li = document.createElement('li');
    li.className = 'list-group-item';
    li.textContent = `${joueur.nom}: ${joueur.score} points`;
    classementEl.appendChild(li);
});

